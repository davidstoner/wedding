const express = require('express')
const bodyParser = require('body-parser')
const sqlite3 = require('sqlite3')

const app = express()

app.use(express.static('public'))
app.use(bodyParser.urlencoded({ extended: true }))

app.get('/', (req, res) => {
  res.render('/index.html')
})

app.post('/', (req, res) => {
  console.log(req.body)
  const db = new sqlite3.Database('rsvp.sqlite')
  db.run("INSERT INTO guests (name, email, attending) VALUES (?, ?, ?)", req.body.name, req.body.email, req.body.attending)
  db.close()
  res.send('Got a POST request.')
})

app.listen(8081, () => console.log('Example app listening on port 3000!'))